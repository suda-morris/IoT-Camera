/*
 * fh_auido_mpipara.h
 *
 *  Created on: 2015��2��15��
 *      Author: fanggm
 */

#ifndef FH_AUIDO_MPIPARA_H_
#define FH_AUIDO_MPIPARA_H_
#include "type_def.h"
#include "acw.h"

// typedef struct{
//	FH_UINT32 len;
//	FH_UINT8 *data;
//}FH_AC_FRAME_S;
//
// typedef enum{
//	FH_AC_MIC_IN = 0,
//	FH_AC_LINE_IN = 1,
//	FH_AC_SPK_OUT = 2,
//	FH_AC_LINE_OUT = 3
//}FH_AC_IO_TYPE_E;
//
//
// typedef struct {
//	FH_AC_IO_TYPE_E io_type;
//	FH_AC_SAMPLE_RATE_E sample_rate;
//	FH_AC_BIT_WIDTH_E bit_width;
//	FH_UINT32 channels;         //ͨ������
//	FH_UINT32 period_size;      //һ֡����еĲ�������
//	FH_UINT32 volume;
//} FH_AC_CONFIG;

#endif /* FH_AUIDO_MPIPARA_H_ */
