#include <gcc/delay.h>

void calibrate_delay(void);
