#ifndef __SADC_TEST__
#define __SADC_TEST__

void sadc_demo_init();

#endif
