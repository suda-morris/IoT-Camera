#ifndef __GPIO_TEST__
#define __GPIO_TEST__

void gpio_demo_init();

#endif
